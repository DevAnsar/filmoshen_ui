const express = require('express');
const next = require('next');
const cookieParser = require('cookie-parser');
const axios = require('axios');

const ZarinpalCheckout = require('zarinpal-checkout');
const bodyParser = require('body-parser');

const port = parseInt(process.env.PORT, 10) || 3000;
const dev = process.env.NODE_ENV !== 'production';
const app = next({dev});
const handle = app.getRequestHandler();

app.prepare()
    .then(() => {
        const server = express();

        server.use(cookieParser());

        server.use(bodyParser.urlencoded({extended: false}));
        server.use(bodyParser.json());


        /**
         * Initial ZarinPal module.
         * @param {String} 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' [MerchantID]
         * @param {bool} false [toggle `Sandbox` mode]
         */
        var zarinpal = ZarinpalCheckout.create('xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx', true);

        /**
         * Route: PaymentRequest [module]
         * @return {String} URL [Payement Authority]
         */
        server.get('/PaymentRequest/:id', function (req, res) {

           // axios.post(`${process.env.BaseUrl}/api/site/create_payment`, {
           //      authority :'xxxxx',
           //      subscribe_id:1,
           //      api_token:req.cookies.token,
           //      amount:1000
           //  })
           //      .then(set_pay_res => {
           //          if (set_pay_res.data.status===1){
           //              res.redirect(response.url);
           //          }
           //      }).catch(err => console.log(err));
            axios.post(`http://192.168.1.102:8000/api/site/test`)
                .then(set_pay_res => {
                    return app.render(req, res, '/', req.query);
                }).catch(err => console.log(err));

            // zarinpal.PaymentRequest({
            //     Amount: '1000',
            //     CallbackURL: 'http://localhost:3000/PaymentVerification',
            //     Description: 'خرید اشتراک از فیلیمو',
            //     Email: 'ansaramman@gmail.com',
            //     Mobile: '09306029572'
            // }).then(async response => {
            //     console.log('PaymentRequest', response);
            //     if (response.status == 100) {
            //          res.redirect(response.url);
            //     }
            // }).catch(function (err) {
            //     console.log(err);
            // });
        });

        /**
         * Route: PaymentVerification [module]
         * @return {number} RefID [Check Paymenet state]
         */
        server.get('/PaymentVerification', function (req, res) {
            console.log('PaymentVerification req', req)
            // zarinpal.PaymentVerification({
            //     Amount: req.params.amount,
            //     Authority: req.params.token,
            // }).then(function (response) {
            //     if (response.status == 101) {
            //         console.log("Verified! Ref ID: " + response.RefID);
            //     } else {
            //         console.log(response);
            //     }
            // }).catch(function (err) {
            //     console.log(err);
            // });
        });

        server.get('/login', (req, res) => {
            if (req.cookies.token) {
                res.redirect('/');
            } else {
                return app.render(req, res, '/login', req.query);
            }
        });

        server.get('/register', (req, res) => {
            if (req.cookies.token) {
                res.redirect('/');
            } else {
                return app.render(req, res, '/register', req.query);
            }
        });

        server.get('/subscribe/:id', (req, res) => {
            if (req.cookies.token) {
                res.redirect(`http://192.168.1.102:8000/site/payment/get/${req.params.id}/?api_token=${req.cookies.token}`)
            } else {
                return app.render(req, res, '/register', req.query);
            }
        });

        server.get('*', (req, res) => {
            return handle(req, res);
        });

        server.listen(port, (err) => {
            if (err) throw err;
            console.log(`> Ready on http://localhost:${port}`);
        });
    })
    .catch((ex) => {
        console.error(ex.stack);
        process.exit(1);
    });
