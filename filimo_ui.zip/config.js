module.exports = {
  // API: 'http://localhost:8000',
  API: 'http://192.168.1.102:8000',
  // API: 'https://filimoserver.liara.run',
};
