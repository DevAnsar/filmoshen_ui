
export const AUTHENTICATE = 'authenticate';
export const DEAUTHENTICATE = 'deauthenticate';
