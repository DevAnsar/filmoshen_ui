import authActions from './authActions';

export default {
  ...authActions,
};
